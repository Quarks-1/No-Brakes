Project Name: No Brakes!
Description: No brakes is an endlees maze solving game which you try to go
as fast as possible while avoiding crashing.  There is an optional enemy AI 
that will chase you around, which makes the game even harder.

How to run the game:
Please launch the tp3.py file and compile and run.  It will load the full game.
